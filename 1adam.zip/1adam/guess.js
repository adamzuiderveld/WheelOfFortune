var wheel = [     50000,
                  5000,
                  8500,
                  3000,
                  5000,
                  4500,
                  "Lose a Turn",
                  4000,
                  9500,
                  3500,
                  5000,
                  6500,
                  "Bankrupt",
                  "Bankrupt",
                  "Bankrupt",
                  "Bankrupt",
                  "Bankrupt",
                  "Bankrupt",
                  "Bankrupt",
                  7000,
                  3000,
                  3000,
                  8000,
                  9000,
                  6000,
                  3000,
                  5500,
                  7500,
                  4000,
                  5000,
                  3000
                              ]

var words = [
            "TEST THIS",
            "HELP ME",
            "OK NOW",
            "JIGGAMAN"
                  ]
var helper;
var turnNum=0;
var wordArray=[]; //used to displsy word as "_,_,_,_,_"
var guessedLetters=[]; 
var chosenWord;
var max=25;
var min=0;             
// var points=0;
var firstOcc;
var wordAsArray;
var pointsP1=0;
var pointsP2=0;
//if %2==0, p1 turn, else p2 turn
var playerTurn=2;



//Displayer current players turn
function whichPlayer(){
      if(playerTurn%2==0) {
      document.getElementById("pTurn").innerHTML = "Player 1's Turn";  
      console.log("Player 1 turn"); 
      }
      else {
            console.log("player 2 turn");
            document.getElementById("pTurn").innerHTML = "Player 2's Turn";
      }
}

function wordToArray(word){
      var str=word;
      wordAsArray=chosenWord.split("")
      console.log(wordAsArray);
}

//word 1= array of words, word2 will be chosenword
//function determines if word has been found completely.
function compareEndGame(word1,word2){
var x=wordArray.join("");
console.log(x);
console.log(wordArray);
if(x==word2){
      console.log("GAME OVER");
      if(pointsP1>pointsP2){
            alert("Player 1 wins with $" + pointsP1);
      }
      else if(pointsP2>pointsP1){
                  alert("Player 2 wins with $" + pointsP2);
      }
      alert("Game has completed!!");
      document.getElementById("startGame").style.display = "inline";
      //show word with underscores
      document.getElementById("underscores").style.display = "none";
      //reveal spin button to the world!
      document.getElementById("myBtn").style.display = "none";
      location.reload();
}
}

//get random word from array!!
function getWord(){
      chosenWord=words[Math.floor(Math.random() * words.length)]
      wordArray=[];
      //turns word into undersdores
      for (var i=0;i<chosenWord.length;i++){

             wordArray[i]="_";
      }
      console.log(chosenWord);
      wordToArray(chosenWord);
            console.log(chosenWord);
//puts space in underscores where neeeded
            for(var j=0;j<chosenWord.length;j++){
            if (chosenWord[j]==" "){
                  wordArray[j]=" ";
            }
      }
      document.getElementById("underscores").innerHTML = wordArray;
      console.log(wordArray);
}

//FIND EACH INDEX OF GUESSED LETTER IN WORD
//https://stackoverflow.com/questions/3410464/how-to-find-indices-of-all-occurrences-of-one-string-in-another-in-javascript
function getIndicesOf(searchStr, str, caseSensitive) {
    var searchStrLen = searchStr.length;
    if (searchStrLen == 0) {
        return [];
    }
    var startIndex = 0, index, indices = [];
    if (!caseSensitive) {
        str = str.toUpperCase();
        searchStr = searchStr.toUpperCase();
    }
    while ((index = str.indexOf(searchStr, startIndex)) > -1) {
        indices.push(index);
        startIndex = index + searchStrLen;
    }
    return indices;
}

//ADD POINTS TO TOTAL
function revealPoints(add){

      if(playerTurn%2==0){         
      pointsP1+=helper;
      document.getElementById("pointsPlayer1").innerHTML = "You have  $" + pointsP1;
                  document.getElementById("myBtn").style.display = "inline";
                        }

      else{
      pointsP2+=helper;
      document.getElementById("pointsPlayer2").innerHTML = "You have  $" + pointsP2;
                  document.getElementById("myBtn").style.display = "inline";
                  }         

            }
      


//REVEAL THE LETTER FOUND AT INDEX...
function revealLetter(index,letter){
      // playerTurn++;
      wordArray[index]=letter;
      console.log(wordArray)
      document.getElementById("underscores").innerHTML = wordArray;
      //only add points for first instance of letter found,
      revealPoints(helper);      
}
//same as letter but doesnt add points if guessed correctly
function revealVowels(index,letter){
      // playerTurn++;
      wordArray[index]=letter;
      console.log(wordArray)
      document.getElementById("underscores").innerHTML = wordArray;
      //only add points for first instance of letter found,
}

//START GAME....set word, show underscores, and reveal spin button
//then hide start button!
document.getElementById("startGame").addEventListener("click", function(){
      //set the word from array
      getWord();
      //hide start button
      document.getElementById("startGame").style.display = "none";
      //show word with underscores
      document.getElementById("underscores").innerHTML = wordArray;
      //reveal spin button to the world!
      document.getElementById("myBtn").style.display = "inline";

});

//hides vowel button after you spin post choosing a vowel
function hide(){
            document.getElementById("vowels").style.display = "none";
}

//SPIN BUTTON handler..
document.getElementById("myBtn").addEventListener("click", function(){
      document.getElementById("myBtn").onclick = hide();
      console.log("spinning.....")
      //helper...spins wheel for random value from arrau
      helper = wheel[Math.floor(Math.random() * (max - min)) + min];
      //which players turn?
      whichPlayer();
      //show spin value on html...
      document.getElementById("spinValue").innerHTML = "You spun for: $" + helper;
      //show word _,_,_,_ on board
      document.getElementById("underscores").innerHTML = wordArray;
      document.getElementById("letterBoard").style.display = "inline";
      document.getElementById("myBtn").style.display = "none";
      // playerTurn++;
      if(helper=="Bankrupt"){
            if(playerTurn%2==0){
                  console.log("Player 1 Bankrupt")
            pointsP1=0;
            document.getElementById("pointsPlayer1").innerHTML = "You went Bankrupt! Now have  $" + pointsP1;
            document.getElementById("myBtn").style.display = "inline";
            document.getElementById("letterBoard").style.display = "none";
            playerTurn++;
}     
            else{
                  console.log("Player 2 Bankrupt")
            pointsP2=0;
            document.getElementById("pointsPlayer2").innerHTML = "You went Bankrupt! Now have  $" + pointsP2;
            document.getElementById("myBtn").style.display = "inline";
            document.getElementById("letterBoard").style.display = "none";
            playerTurn++;
}
      }
      if(helper=="Lose a Turn"){
            console.log("Lose a turn")
            document.getElementById("letterBoard").style.display = "none";
            document.getElementById("myBtn").style.display = "inline";
            playerTurn++;
      }
      document.getElementById("vowels").style.display = "hide";
});

//handles event where you vuy a vowel
document.getElementById("vowels").addEventListener("click", function(){
      document.getElementById("vowelBoard").style.display = "inline";
      document.getElementById("myBtn").style.display = "none";
      document.getElementById("vowels").style.display = "none";
});


//should show up after you spin!
//ALPHABET BUTTONS TO PRESS....DISAPPEARS WHEN PRESSED
//when letter is chosen....lets increase turnNum and check the word for the letter picked
function setLetter(letter) {
    document.getElementById('name').innerHTML = document.getElementById('name').innerHTML + letter;
    document.getElementById(letter).style.display = "none";
    var indices=getIndicesOf(letter,chosenWord);
    console.log(indices)
    document.getElementById("output").innerHTML = indices + "";
   firstOcc=1;  

      document.getElementById("letterBoard").style.display = "none";
      document.getElementById("myBtn").style.display = "inline";

    //for each indices found, reveal the letter found in array...then add points again
    indices.forEach(function (indices){
    revealLetter(indices,letter);
      firstOcc++;
      whichPlayer();
      console.log("Found a letter!")
      compareEndGame(wordArray,chosenWord);
          });

    //if letter guessed is in word, take another turn!
      if(firstOcc==1){
            playerTurn++;
            firstOcc++;
      }
      //if current player has at least $250, allow them to buy a vowel before next spin
      if(playerTurn%2==0 && pointsP1>250){
      document.getElementById("vowels").style.display = "inline";
      }
      else if(playerTurn%2!=0 && pointsP2>250){
      document.getElementById("vowels").style.display = "inline";
      }

}


//same as setletter but for vowels.
function setVowel(letter) {
         if(playerTurn%2==0){
            pointsP1-=250;
            document.getElementById("pointsPlayer1").innerHTML = "You have  $" + pointsP1;

         }
         else{
            pointsP2-=250;
            document.getElementById("pointsPlayer2").innerHTML = "You have  $" + pointsP2;
         }
    document.getElementById('name').innerHTML = document.getElementById('name').innerHTML + letter;
    document.getElementById(letter).style.display = "none";
    var indices=getIndicesOf(letter,chosenWord);
    console.log(indices)
    document.getElementById("output").innerHTML = indices + "";
    firstOcc=1;  
    document.getElementById("vowelBoard").style.display = "none";
    document.getElementById("myBtn").style.display = "inline";
    //for each indices found, reveal the letter found in array...then add points again
    indices.forEach(function (indices){
    revealVowels(indices,letter);
      firstOcc++;
      whichPlayer();
      console.log("Found a letter!")
      compareEndGame(wordArray,chosenWord);
          });
    //if letter guessed is in word, guess again!
      if(firstOcc==1){
            playerTurn++;
            firstOcc++;
            whichPlayer();
            document.getElementById("vowels").style.display = "none";
      }
      if(playerTurn%2==0 && pointsP1>250){
      document.getElementById("vowels").style.display = "inline";
      }
      else if(playerTurn%2!=0 && pointsP2>250){
      document.getElementById("vowels").style.display = "inline";
      }
      whichPlayer();
}
